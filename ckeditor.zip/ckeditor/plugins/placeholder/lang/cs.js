﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('placeholder','cs',{placeholder:{title:'Vlastnosti vyhrazeného prostoru',toolbar:'Vytvořit vyhrazený prostor',text:'Vyhrazený text',edit:'Upravit vyhrazený prostor',textMissing:'Vyhrazený prostor musí obsahovat text.'}});
